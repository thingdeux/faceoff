function love.conf(t)
	t.screen.width = 1024
	t.screen.height = 768
	t.title = "Faceoff"
	t.author = "Joshua Johnson"	
	t.vsync = true
end